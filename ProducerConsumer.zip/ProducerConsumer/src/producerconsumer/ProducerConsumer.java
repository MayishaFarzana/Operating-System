/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package producerconsumer;

import java.util.ArrayList;

/**
 *
 * @author SayefReyadh
 */
public class ProducerConsumer {

    ArrayList<Integer> list = new ArrayList<>();
    int capacity;

    public ProducerConsumer(int capacity) {
        this.capacity = capacity;
    }

    public void produceItem() throws InterruptedException {
        int itemNumber = 0;
        while (true) {
            synchronized (this) {
                while (list.size() == capacity) {
                    wait();
                }
                System.out.println("Producer produced item number : " + itemNumber);
                list.add(itemNumber++);
                notify();
                Thread.sleep(2000); // using this sleep to print in console
                // nahole onk fast print hobe
            }
        }
    }

    public void consumeItem() throws InterruptedException {
        while (true) {
            synchronized (this) {
                while (list.size() == 0) {
                    wait();
                }
                int item = list.remove(0);
                System.out.println("Consumer consumed item number : " + item);
                notify();
                Thread.sleep(2000);
            }
        }
    }
}
